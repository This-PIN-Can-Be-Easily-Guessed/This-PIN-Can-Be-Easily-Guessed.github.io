#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Metadata
__author__     = "Maximilian Golla"
__credits__    = ["Philipp Markert", "Daniel V. Bailey", "Maximilian Golla", "Markus Duermuth", "Adam J. Aviv"]
__license__    = "The MIT License (MIT)"
__version__    = "1.0.0, 2020-03-11"
__maintainer__ = "Maximilian Golla"
__email__      = "maximilian.golla@csp.mpg.de"
__status__     = "Development"

import sys, datetime, itertools

# aaaaaa
# 10 PINs
def p0(pin):
    if pin[0] == pin[1] == pin[2] == pin[3] == pin[4] == pin[5]:
        return True
    return False

# abcabc
# 1000 PINs
def p1(pin):
    if pin[0] == pin[3] and pin[1] == pin[4] and pin[2] == pin[5]:
        return True
    return False

# abccba
# 1000 PINs
def p2(pin):
    if pin[0] == pin[5] and pin[1] == pin[4] and pin[2] == pin[3]:
        return True
    return False

# ababab
# 100 PINs
def p3(pin):
    if pin[0] == pin[2] == pin[4] and pin[1] == pin[3] == pin[5]:
        return True
    return False

# ababa[0-9]
# 1000 PINs
def p4(pin):
    if pin[0] == pin[2] == pin[4] and pin[1] == pin[3]:
        return True
    return False

# series
# 14 PINs
def p5(pin):
    series = ['012345',
              '098765',
              '123456',
              '123654',
              '234567',
              '321654',
              '345678',
              '456789',
              '543210',
              '654321',
              '765432',
              '789456',
              '876543',
              '987654']

    if pin in series:
        return True
    return False

# common
# 6 PINs
'''
Ding Wang, Qianchen Gu, Xinyi Huang, and Ping Wang.
Understanding Human-Chosen PINs: Characteristics, Distribution and Security.
In ACM Asia Conference on Computer and Communications Security, ASIA CCS ’17, pages 372–385, Abu Dhabi, United Arab Emirates, April 2017. ACM.
'''
def p6(pin):
    common = ['030379', # Seem to be of no obvious meaning, but common in Yahoo
              '101471', # Seem to be of no obvious meaning, but common in Yahoo
              '112233', # Pattern: aabbcc
              '159753', # Pattern: X on the keypad
              '147258', # Pattern: first two columns on the keypad
              '520131'] # Chinese "I love you forever" (520131-4 missing)

    if pin in common:
        return True
    return False

def check_pin(pin):
    result = []
    if p0(pin):
        result.append('p0 (aaaaaa)')
    if p1(pin):
        result.append('p1 (abcabc)')
    if p2(pin):
        result.append('p2 (abccba)')
    if p3(pin):
        result.append('p3 (ababab)')
    if p4(pin):
        result.append('p4 (ababa[0-9])')
    if p5(pin):
        result.append('p5 (series)')
    if p6(pin):
        result.append('p6 (common)')
    return result

# Generates all theoretically possible PINs == 1000000
def generate():
    allpins = []
    pin_length = 6
    alphabet = [0,1,2,3,4,5,6,7,8,9]
    for candidate in itertools.product(alphabet, repeat=pin_length):
        pin = ''.join(str(i) for i in candidate)
        allpins.append(pin)
    return allpins

def main():
    generated = generate()
    blacklisted = 0
    for pin in generated:
        blacklist_check = check_pin(pin)
        if len(blacklist_check) != 0:
            blacklisted += 1
            print(pin, blacklist_check)
    print("blacklisted:", blacklisted, "({} %)".format((blacklisted*100.0)/len(generated)))

if __name__ == '__main__':
    main()
